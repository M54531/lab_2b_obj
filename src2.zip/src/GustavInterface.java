public interface GustavInterface {
    public void increaseAngleFromInterface();
    public void decreaseAngleFromInterface();
    public void setTurboFromInterface(boolean onOff);
}
