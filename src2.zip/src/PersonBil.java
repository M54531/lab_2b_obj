import java.awt.*;

public abstract class PersonBil extends Car{
    public PersonBil(int n, Color c, int eng,int s,String name){
        super(n, c, eng, s, name, 0);
    }

    public void increaseAngleFromInterace() {} // The methods aren't abstract, but they shouldn't do anything for cars that aren't trucks.
    public void decreaseAngleFromInterface() {}
    public void setTurboFromInterface(boolean bool) {}
}
