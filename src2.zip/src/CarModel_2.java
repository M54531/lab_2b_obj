import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

public class CarModel_2{
    private ArrayList<Car> cars = new ArrayList<>();
    public ArrayList<BufferedImage> carImages=new ArrayList<>();
    public ArrayList<Point> carPosition=new ArrayList<>();
    private GustavInterface IState; // instance variable whose type is GustavInterface

    public CarModel_2(Car car) {
        cars.add(car);
    }
    public CarModel_2(){
    }

  /*  public void addCar(Car car){//alternativ 1 om vi skapar car i carapplication
        cars.add(car);
        int index=cars.indexOf(car);
        try{
            carImages.add(ImageIO.read(CarModel.class.getResourceAsStream("pics/"+cars.get(index).getClass().getName()+".jpg")));
        }catch(IOException ex){
            System.out.println("error");
        }
    }
*/
    public void addVolvo(){//alternativ 2 om vi ska kunna lägga till bilar utan att skapa Car i carapplication
        cars.add(new Volvo240());
        carPosition.add(new Point(0,0));
        int index=cars.size();
        //cars.get(0).gas(1);
        try{
            carImages.add(ImageIO.read(CarModel.class.getResourceAsStream("pics/Volvo240.jpg")));
        }catch(IOException ex){
            System.out.println("error");
        }
    }
    public void addSaab(){  //alternativ 2 om vi ska kunna lägga till bilar utan att skapa Car i carapplication
        cars.add(new Saab95());
        carPosition.add(new Point(0,0));
        int index=cars.size();
        //cars.get(0).gas(1);
        try{
            carImages.add(ImageIO.read(CarModel.class.getResourceAsStream("pics/Saab95.jpg")));
        }catch(IOException ex){
            System.out.println("error");
        }
    }
    public void addScania(){    //alternativ 2 om vi ska kunna lägga till bilar utan att skapa Car i carapplication
        cars.add(new Scania());
        carPosition.add(new Point(0,0));
        int index=cars.size();
        //cars.get(0).gas(1);
        try{
            carImages.add(ImageIO.read(CarModel.class.getResourceAsStream("pics/Scania.jpg")));
        }catch(IOException ex){
            System.out.println("error");
        }
    }

    public void updatePos(){//moves all cars and updates carPoistion array.
        for (Car car : cars) {
            double xx = car.getXPos()+car.getCurrentSpeed()*Math.cos(car.getTheta());
            double yy =car.getYPos()+car.getCurrentSpeed()*Math.sin(car.getTheta());
            if (xx > 700 || xx < 0 || yy > 560 || yy < 0) {
                car.turnRight();
                car.turnRight();
                car.stopEngine();
                car.startEngine();
            }
            car.move();
            int index = cars.indexOf(car);
            carPosition.set(index,new Point((int)car.getXPos(),(int)car.getYPos()));
        }
    }

    // Calls the gas method for each car once
    void gas(int amount) {
        double gas = ((double) amount) / 100;
        for (Car car : cars
        ) {
            car.gas(gas);
        }
    }
    void brake(int amount) {
        double brake = ((double) amount) / 100;
        for (Car car : cars
        ) {
            car.brake(brake);
        }

    }
    void start() {
        for (Car car : cars
        ) {
            car.startEngine();
        }
    }
    void stop() {
        for (Car car : cars
        ) {
            car.stopEngine();
        }
    }
    void turbo(boolean onOff){
        for(Car car:cars){
            if(car instanceof Saab95)((Saab95) car).setTurbo(onOff);
        }
    }
    void lift(){
        for(Car car:cars){
            if(car instanceof Scania) {
                ((Scania) car).increaseAngle(70);
                System.out.println(((Scania) car).getPlatfromAngle());
            }
        }
    }

    void lower(){
        for(Car car:cars){
            if(car instanceof Scania) {
                ((Scania) car).decreaseAngle(70);
            }
        }
    }

}
