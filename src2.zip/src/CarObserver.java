import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public interface CarObserver{
    public void actWhenCarHasMoved();
}
