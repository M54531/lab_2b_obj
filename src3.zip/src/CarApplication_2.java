import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class CarApplication_2 {


    CarModel_2 carModel=new CarModel_2();
    CarController carControl=new CarController(carModel);                       //use CarController and Carview
    CarView frame=new CarView("Cars",carControl);                   //Carcontroller includes buttons and extends JPanel
   /* CarView_2 frame=new CarView_2("Cars");                                //use CarController_2 and Carview_2
    CarController_2 carControl=new CarController_2(frame,carModel);*/      //Carview_2 includes buttons
    private Timer timer = new Timer(10,new TimerListener());

    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {//action metoden, anropas av timer varje 10(delay)
            carModel.updatePos();
            frame.updateState(carModel.carImages,carModel.carPosition);
        }
    }

    public static void main(String[] args) {
        CarApplication_2 carapp=new CarApplication_2();
        carapp.carModel.addVolvo();
        carapp.carModel.addScania();
        carapp.carModel.addScania();
        carapp.carModel.addSaab();
        carapp.timer.start();
    }
}