import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarController_2 {
private CarView_2 view;
private CarModel_2 model;

public CarController_2(CarView_2 view,CarModel_2 model){
    this.view=view;
    this.model= model;
    addButtons();
    }

private void addButtons(){
    view.gasButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.gas(view.gasAmount);
        }
    });

    view.brakeButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.brake(view.gasAmount);
        }
    });

    view.turboOnButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.turbo(true);
        }
    });

    view.turboOffButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.turbo(false);
        }
    });

    view.liftBedButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.lift();
        }
    });

    view.lowerBedButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.lower();
        }
    });

    view.startButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.start();
        }
    });

    view.stopButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.stop();
        }
    });
}
}
