import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * This class represents the full view of the MVC pattern of your car simulator.
 * It initializes with being center on the screen and attaching it's controller in it's state.
 * It communicates with the Controller by calling methods of it when an action fires of in
 * each of it's components.
 * TODO: Write more actionListeners and wire the rest of the buttons
 **/

public class CarView extends JFrame {
    private int X = 800;
    private int Y = 800;
    ArrayList<BufferedImage> images=null;
    ArrayList<Point> points=new ArrayList<>();
    CarController carcon;
    JPanel draw = new JPanel(){
        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            int k=0;
            for(Integer i=0;i<points.size();i++){
                int index = points.indexOf(i);
                try {
                    g.drawImage(images.get(i), points.get(i).x, points.get(i).y+k, null); // see javadoc for more info on the parameters
                } catch (Exception e) {
                    e.printStackTrace();
                }
                k=k+100;
            }
        }
    };

    public void updateState(ArrayList<BufferedImage> images,ArrayList<Point> points){
        this.images=images;
        this.points=points;
        this.draw.repaint();
    }

    JPanel controlPanel = new JPanel();



    // Sets everything in place and fits everything
    // TODO: Take a good look and make sure you understand how these methods and components work
    public CarView(String framename,CarController carcon){
        this.carcon=carcon;
        initComponents(framename);
    }
    public CarView(String framename,Integer X,Integer Y,CarController carcon){
        this.carcon=carcon;
        this.X=X;
        this.Y=Y;
        initComponents(framename);
    }

    private void initComponents(String title) {
        draw.setDoubleBuffered(true);
        draw.setPreferredSize(new Dimension(X, Y-240));
        draw.setBackground(Color.green);
        this.add(draw);


        this.setTitle(title);
        this.setPreferredSize(new Dimension(X, Y));
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));

        carcon.gasPanel.add(carcon.gasLabel);
        carcon.gasPanel.add(carcon.gasSpinner);
        //carcon.buildGasPanel;
        this.add(carcon.gasPanel);
        carcon.add2();//buildbuttons
        this.add(carcon);
        this.add(carcon.startButton);
        this.add(carcon.stopButton);


        // Make the frame pack all it's components by respecting the sizes if possible.
        this.pack();

        // Get the computer screen resolution
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        // Center the frame
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        // Make the frame visible
        this.setVisible(true);
        // Make sure the frame exits when "x" is pressed
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
