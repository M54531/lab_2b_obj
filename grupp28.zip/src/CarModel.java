import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class CarModel implements CarProperties, CarObserver {
    private ArrayList<Car> cars = new ArrayList<>();
    public ArrayList<BufferedImage> carImages = new ArrayList<>();
    public ArrayList<Point> carPosition = new ArrayList<>();
    public ArrayList<CarObserver> observers = new ArrayList<>();

    //public CarModel_2(Car car) {cars.add(car);}
    public CarModel() {
    }


    public void addCar(Car car) { //adds a car with picture and initial position
        cars.add(car);
        carPosition.add(new Point(0, 0));
        int index = cars.indexOf(car);
        try {
            carImages.add(ImageIO.read(CarModel.class.getResourceAsStream("pics/" + cars.get(index).getClass().getName() + ".jpg")));
        } catch (IOException ex) {
            System.out.println("error");
        }
    }

    public void updatePos() {//moves all cars and updates the carPosition array.
        for (Car car : cars) {
            double xx = car.getXPos() + car.getCurrentSpeed() * Math.cos(car.getTheta());
            double yy = car.getYPos() + car.getCurrentSpeed() * Math.sin(car.getTheta());
            if (xx > 700 || xx < 0 || yy > 560 || yy < 0) { // Turn the car around if has hit a wall
                car.turnRight();
                car.turnRight();
                car.stopEngine();
                car.startEngine();
            }
            car.move();
            int index = cars.indexOf(car);
            carPosition.set(index, new Point((int) car.getXPos(), (int) car.getYPos()));
        }
    }

    // Calls the gas method for each car once
    void gas(int amount) {
        double gas = ((double) amount) / 100;
        for (Car car : cars
        ) {
            car.gas(gas);
        }
    }

    void brake(int amount) {
        double brake = ((double) amount) / 100;
        for (Car car : cars
        ) {
            car.brake(brake);
        }

    }

    void start() {
        for (Car car : cars
        ) {
            if (car.getCurrentSpeed() == 0) car.startEngine();
        }
    }

    void stop() {
        for (Car car : cars
        ) {
            car.stopEngine();
        }
    }

    void turbo(boolean onOff) {
        setTurbo(onOff);
    }

    void lift() {
        increaseAngle();
    }

    void lower() {
        decreaseAngle();
    }

    public ArrayList<Double> getSpeed() {//returns array of the cars current speed
        ArrayList<Double> speed = new ArrayList<>();
        for (Car car : cars) {
            speed.add(car.getCurrentSpeed());
        }
        return speed;
    }

    public void removeCar() {// removes last car
        int lastind = cars.size();
        if (lastind > 0) {
            try {
                cars.remove(lastind - 1);
                carImages.remove(lastind - 1);
                carPosition.remove(lastind - 1);
            } catch (Exception e) {
                System.out.println("error in Carmodel_removeCar");
            }
        }
    }

    public void addRandomCar() {//adds a random car
        if (cars.size() < 10) {
            int r = new Random().nextInt(3);
            switch (r) {
                case 0:
                    addCar(new Volvo240());
                    break;
                case 1:
                    addCar(new Saab95());
                    break;
                case 2:
                    addCar(new Scania());
                    break;
            }
        }
    }

    @Override
    public void updateView(CarModel carmodel) {
        for (CarObserver observer : observers) {
            observer.updateView(this);
        }
    }

    public void addObserver(CarObserver obs) {
        observers.add(obs);
    }

    public void removeObserver(CarObserver obs) {
        observers.remove(obs);
    }
    @Override
    public void increaseAngle() { // Composite pattern
        for (Car car : cars) car.increaseAngle();
    }
    @Override
    public void decreaseAngle() {
        for (Car car : cars) car.decreaseAngle();
    }
    @Override
    public void setTurbo(boolean onOff) {
        for (Car car : cars) car.setTurbo(onOff);
    }

}
