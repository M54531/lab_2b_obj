public interface CarProperties {
    public void increaseAngle();
    public void decreaseAngle();
    public void setTurbo(boolean onOff);
}
