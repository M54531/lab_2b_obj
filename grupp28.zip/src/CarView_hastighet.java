import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CarView_hastighet extends JPanel implements CarObserver{
    private final String text;
    ArrayList<JLabel> labels = new ArrayList<>();
    int labelCount;

    public CarView_hastighet(String text,Integer rows){
        labelCount=rows;
        this.text=text;

        setLayout(new GridLayout(rows, 1));
        setPreferredSize(new Dimension(100,200));
        setBackground(Color.CYAN);

        for(Integer a=0;a<rows;a++){
            labels.add(new JLabel(text));
            this.add(labels.get(a),a);
        }
    }

    private void rebuild(Integer i){//rebuilds JPanel to i JLabels
        this.setLayout(new GridLayout(10, 1));
        labels=new ArrayList<>();
        this.removeAll();
        for(Integer a=0;a<i;a++){
            labels.add(new JLabel(text));
            this.add(labels.get(a),a);
        }
        this.repaint();
        labelCount=i;
    }

    public void updateLabel(ArrayList<Double> ints){
        if(labelCount!=ints.size()){//rebuild panel if the number of elements has changed
            rebuild(ints.size());
        }
        int index = 0;
        double a=0;
        for(JLabel label:labels){
            try{
                a=ints.get(index);
            }catch (  Exception e  ){
               System.out.println("error carviewhastighet");
            }
            label.setText(text+(index+1)+": "+a);
            index++;
        }
    }

    @Override
    public void updateView(CarModel carModel) {
        updateLabel(carModel.getSpeed());
    }
}
