public interface CarObserver{
    public void updateView(CarModel carmodel);
}
