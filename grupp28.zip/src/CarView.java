import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * This class represents the full view of the MVC pattern of your car simulator.
 * It initializes with being center on the screen and attaching it's controller in its state.
 * It communicates with the Controller by calling methods of it when an action fires of in
 * each of its components.
 * TODO: Write more actionListeners and wire the rest of the buttons
 **/

public class CarView extends JFrame implements CarObserver{
    private int X = 900;
    private int Y = 840;
    ArrayList<BufferedImage> images=null;
    ArrayList<Point> points=new ArrayList<>();
    JPanel draw = new JPanel(){
        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            int k=0;
            for(Integer i=0;i<points.size();i++){
                int index = points.indexOf(i);
                try {
                    g.drawImage(images.get(i), points.get(i).x, points.get(i).y+k, null); // see javadoc for more info on the parameters
                } catch (Exception e) {
                    e.printStackTrace();
                }
                k=k+60;
            }
        }
    };

    public void updateState(ArrayList<BufferedImage> images,ArrayList<Point> points){
        this.images=images;
        this.points=points;
        this.draw.repaint();
    }

    // Sets everything in place and fits everything
    // TODO: Take a good look and make sure you understand how these methods and components work
    public CarView(String framename){
        initComponents(framename);
    }
    public CarView(String framename,Integer X,Integer Y){
        this.X=X;
        this.Y=Y;
        initComponents(framename);
    }

    private void initComponents(String title) {
        draw.setDoubleBuffered(true);
        draw.setPreferredSize(new Dimension(800, 600));
        draw.setBackground(Color.green);
        this.add(draw);


        this.setTitle(title);
        this.setPreferredSize(new Dimension(X, Y));
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));



        // Make the frame pack all it's components by respecting the sizes if possible.
        this.pack();

        // Get the computer screen resolution
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        // Center the frame
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        // Make the frame visible
        this.setVisible(true);
        // Make sure the frame exits when "x" is pressed
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void addComponent(JPanel comp){
        this.add(comp);
    }

    @Override
    public void updateView(CarModel carmodel) {
        updateState(carmodel.carImages,carmodel.carPosition);
    }
}
