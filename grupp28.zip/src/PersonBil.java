import java.awt.*;

public abstract class PersonBil extends Car{
    public PersonBil(int n, Color c, int eng, int s, String name, int i){
        super(n, c, eng, s, name, 0);
    }

    @Override
    public void increaseAngle() {}
    @Override
    public void decreaseAngle() {}
    @Override
    public abstract void setTurbo(boolean bool);
}
