import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarApplication {


    CarModel carModel=new CarModel();
    CarController carControl=new CarController(carModel);  //use CarController and Carview
    CarView frame=new CarView("Cars",820,840);
    CarView_hastighet hastighetLabel=new CarView_hastighet("Car",10);

    private Timer timer = new Timer(10,new TimerListener());

    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {//action metoden, anropas av timer varje 10(delay)
            carModel.updatePos();
            carModel.updateView(carModel);
        }
    }

    public static void main(String[] args) {

        CarApplication carapp=new CarApplication();

        carapp.frame.add(carapp.hastighetLabel);///add components to JFrame
        carapp.frame.add(carapp.carControl.gasPanel);
        carapp.carControl.add();
        carapp.frame.add(carapp.carControl);
        carapp.frame.add(carapp.carControl.startButton);
        carapp.frame.add(carapp.carControl.stopButton);
        carapp.frame.pack();

        carapp.carModel.addObserver(carapp.frame);
        carapp.carModel.addObserver(carapp.hastighetLabel);
        carapp.timer.start();

    }
}