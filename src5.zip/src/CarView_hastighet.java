import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CarView_hastighet extends JPanel {
    private String text;
    ArrayList<JLabel> labels=new ArrayList<>();
    public CarView_hastighet(String text,Integer rows){
        this.text=text;
        setLayout(new GridLayout(rows, 1));
        setPreferredSize(new Dimension(100,200));
        setBackground(Color.CYAN);

        for(Integer a=0;a<rows;a++){
            labels.add(new JLabel(text));
            this.add(labels.get(a),a);
        }
    }

    public void updateLabel(ArrayList<Integer> ints){
        int index = 0;
        int a=0;
        for(JLabel label:labels){
            try{
                a=ints.get(index);
            }catch (  Exception e  ){
                System.out.println("error");
            }
            label.setText(text+": "+a+"   ");
            index++;
        }
    }
}
