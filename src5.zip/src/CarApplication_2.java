import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class CarApplication_2 {


    CarModel_2 carModel=new CarModel_2();
    CarController carControl=new CarController(carModel);                       //use CarController and Carview
    CarView frame=new CarView("Cars",800,800);
    CarView_hastighet hastighetLabel=new CarView_hastighet("hastighet",4);
    //Carcontroller includes buttons and extends JPanel
   /* CarView_2 frame=new CarView_2("Cars");                                //use CarController_2 and Carview_2
    CarController_2 carControl=new CarController_2(frame,carModel);*/      //Carview_2 includes buttons
    private Timer timer = new Timer(10,new TimerListener());

    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {//action metoden, anropas av timer varje 10(delay)
            carModel.updatePos();
            frame.updateState(carModel.carImages,carModel.carPosition);
            hastighetLabel.updateLabel(carModel.getSpeed());

            //hastighetLabel.setText("hastighet: "+carModel.getSpeed().get(0)+"         ");
        }
    }

    public static void main(String[] args) {
        /*
        this.add(carcon.gasPanel);
        carcon.add2();
        this.add(carcon);
        this.add(carcon.startButton);
        this.add(carcon.stopButton);
         */
        CarApplication_2 carapp=new CarApplication_2();
        carapp.frame.add(carapp.hastighetLabel);
        carapp.frame.add(carapp.carControl.gasPanel);
        carapp.carControl.add2();
        carapp.frame.add(carapp.carControl);
        carapp.frame.add(carapp.carControl.startButton);
        carapp.frame.add(carapp.carControl.stopButton);

        carapp.carModel.addVolvo();
        carapp.carModel.addScania();
        carapp.carModel.addScania();
        carapp.carModel.addSaab();
        carapp.timer.start();

    }
}